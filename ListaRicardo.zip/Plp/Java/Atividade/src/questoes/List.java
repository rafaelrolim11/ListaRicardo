package questoes;

public class List<T> {

}
