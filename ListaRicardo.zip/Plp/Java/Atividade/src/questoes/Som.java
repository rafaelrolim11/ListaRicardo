package questoes;

import java.util.List;

public class Som {

    private String som;
  
    public Som(String som) {
        this.som = som;
    }
    public void emitirSom() {
        System.out.println(som);
    }

}
