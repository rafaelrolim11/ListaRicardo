package questoes;

public interface Imprimivel {

    void imprimir();

}
